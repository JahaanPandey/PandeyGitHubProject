let rectX = 0
let rectY = 400
let value = 0;

function setup() {
  createCanvas(400, 400);
}

function draw() {

  background(220);

  for (let i = 0; i < 9; i++) {
    console.log(i);

    rectX = rectX += 1;
    if (rectX >= width) {
      if (fr === 30) {
        frameRate(fr);
      }
      rectX = 0;
    }
    rectY = rectY += -1;
    if (rectY >= width) {
      if (fr === 30) {
        frameRate(fr);
      }
      rectX = 0;
    }
  }

  function mousePressed() {
    if (value === 0) {
      value = 355;

    } else {
      value = 0;
    }
  }
  
  fill(value);
  rect(100, 100, 100, 100)
  
  
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(rectX, rectY, 50, 50);


}