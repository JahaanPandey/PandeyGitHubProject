function setup() {
  createCanvas(400, 400);
  background(220);
  colorMode(RGB, 255, 255, 255, 1);
  for (let i = 0; i < 100; i++) {
    for (let j = 0; j < 100; j++) {
      stroke(i, j, 100);
      point(i, j);
    }
  }
}

function draw() {

  noStroke(0)
  fill(255, 0, 0)
  rect(50, 150, 300, 300);

  stroke(255, 0, 0)
  fill(255, 0, 0)
  curve(50, 300, 50, 150, 350, 150, 350, 300);

  stroke(0)
  fill(150, 150, 23)
  triangle(200, 200, 100, 300, 300, 300);

  fill(156, 204, 0)
  arc(200, 293, 80, 80, 3, 0.14, PI + QUARTER_PI);

  fill(255)
  quad(175, 280, 225, 280, 225, 290, 175, 290);
  
  stroke (0)
  noFill()
  curve(200, 200, 100, 350, 300, 350, 200, 200);
  
  fill(255, 0, 0)
  curve(200, 0, 150, 200, 250, 200, 200, 50)




}