let x = 10;
print('The value of x is ' + x);

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  rectMode(CENTER);
  translate(width / 2, height / 2);
  translate(p5.Vector.fromAngle(millis() / 1000, 140));
  rect(0, 0, 100, 100);

  scale(.333);
  rect(0, 0, 100, 100);

  translate(width / 5, height / -.97);
  rotate(PI / 3.0);
  rect(200, 200, 100, 100);

  translate(width / 5, height / -.97);
  rotate(PI / 7.0);
  rect(700, 500, 100, 100);

  angleMode(DEGREES);
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / .8, height / .7);
  push();
  rotate(a);
  rect(400, -5, 40, 10);
  pop();
  angleMode(RADIANS);
  rotate(a); 
  rect(400, -5, 100, 100);
  
  ellipse(0, 50, 33, 33);
  push();
  strokeWeight(10);
  fill(204, 153, 0);
  translate(120, 100);
  ellipse(0, 50, 33, 33)
  pop();
  ellipse(100, 50, 33, 33);
}